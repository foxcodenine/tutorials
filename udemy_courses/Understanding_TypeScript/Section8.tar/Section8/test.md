De quelle couleur est ce panneau ?
What color is this sign?
[ di kel kulur e squ pa-no ? ]

De quelle couleur" → Of what color

"est ce panneau" → is this sign

Ce panneau est rouge.
This sign is red.
[Squ pa-no e ruxġ]

--------------------------------

Le dessin animé est en couleur ?
Is the cartoon in color?
[ le dis-sa anime e_t_qo kulur ? ]

"Le dessin animé" → The cartoon
"est en couleur" → is in color

Oui, le dessin animé est en couleur.
Yes, the cartoon is in color.
[ wi, le dessa anime e_t_qo kulur ]

--------------------------------

Cette émission télé est en couleur ?
Is this TV show in color?
[ set emisjon tele e_t_qo kulur ? ]

"Cette émission télé" → This TV show
"est en couleur" → is in color

Oui, cette émission est en couleur.
Yes, this show is in color.
[ wi, set emisjon e_t_qo kulur ]

--------------------------------

Ceci est un stylo rouge.
This is a red pen.
[ se-si e_t_qa stilo ruxġ ]

"Ceci est" → This is
"un stylo rouge" → a red pen

--------------------------------

Ce morceau de papier est bleu.
This piece of paper is blue.
[ sq marso di papje e blu ]

"Ce morceau de papier" → This piece of paper
"est bleu" → is blue

--------------------------------

French	                          English	                    Use
Ce	                [sq]          This (masc.)	                Before masculine singular noun
Cette	            [set]         This (fem.)	                Before feminine singular noun
Cet	                [set]         This (masc. + vowel/h)	    Before masculine noun starting with a vowel or silent h
Ces	                [se]          These (plural)	            Before plural nouns (any gender)
Ceci / Cela / Ça	[sesi]        This / That	                Standalone / abstract use